package com.fingerlick.beans;
public class orderbeans {
String type;
String Restaurant;
String Location;
String cuisine;
String email;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getRestaurant() {
	return Restaurant;
}
public void setRestaurant(String restaurant) {
	Restaurant = restaurant;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
public String getCuisine() {
	return cuisine;
}
public void setCuisine(String cuisine) {
	this.cuisine = cuisine;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public orderbeans() {
	super();
	// TODO Auto-generated constructor stub
}
public orderbeans(String type, String restaurant, String location,
		String cuisine,String email) {
	super();
	this.type = type;
	Restaurant = restaurant;
	Location = location;
	this.cuisine = cuisine;
	this.email = email;
}



}
