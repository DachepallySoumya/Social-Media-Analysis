package com.fingerlick.beans;

public class orderedlistbeans {
String email; 
String item;
 String price;
 public String getEmail() {
		return email;
}
 public void setEmail(String email) {
		this.email = email;
 }
public String getItem() {
	return item;
}
public void setItem(String item) {
	this.item = item;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public orderedlistbeans(String item, String price,String email) {
	super();
	this.email= email;
	this.item = item;
	this.price = price;
}
public orderedlistbeans() {
	super();
	// TODO Auto-generated constructor stub
}
 
}
