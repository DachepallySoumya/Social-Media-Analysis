package com.fingerlick.dao;


	import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;






	import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Struct;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

import com.fingerlick.beans.UserBeans;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

	public class UserDAO {
		ConnectionDAO cdao;
		Connection conn;
		PreparedStatement st;
		public UserDAO() throws SQLException, ClassNotFoundException {
			System.out.println("after userdao");
			cdao = new ConnectionDAO();
			//System.out.println("connected");
			conn = cdao.getConnection();
		//	System.out.println("b4 create");
			}
	     public int CreateUser(UserBeans ubean) throws SQLException{
	    	 System.out.println("qwer");
			String email = ubean.getEmail();
			System.out.println("13");
			String password = ubean.getPassword();
			System.out.println(email);
			System.out.println(password);
			String query = "INSERT INTO user values(?,?)";	
			int result = 0;
			st = conn.prepareStatement(query);
			st.setString(1, email);
			st.setString(2, password);
			result = st.executeUpdate();
			return result;
			
		}
		
		
		
		public boolean ValidateUser(UserBeans ubean) throws SQLException{
			String email= ubean.getEmail();
			String password = ubean.getPassword();
			boolean result = false;
			String query = "select * from user where email=? and password=?";
			st = conn.prepareStatement(query);
			st.setString(1, email);
			st.setString(2, password);
			ResultSet rst = st.executeQuery();
			while(rst.next()){
				
				result = true;
			}
			
			return result;
			
		}
	} 

