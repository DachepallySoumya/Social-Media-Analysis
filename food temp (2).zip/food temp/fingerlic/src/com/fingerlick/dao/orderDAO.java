package com.fingerlick.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fingerlick.beans.orderbeans;

public class orderDAO {
	ConnectionDAO cdao;
	Connection conn;
	PreparedStatement st;
	public orderDAO() throws SQLException, ClassNotFoundException {
		System.out.println("after orderdao");
		cdao = new ConnectionDAO();
		//System.out.println("connected");
		conn = cdao.getConnection();
	//	System.out.println("b4 create");
		}
     public int CreateOrder(orderbeans obean) throws SQLException{
		String type = obean.getType();
		 String Restaurant = obean.getRestaurant();
		 String Location= obean.getLocation();
		 String cuisine = obean.getCuisine();
		 String email = obean.getEmail();
		System.out.println(type);
		System.out.println(Restaurant);
		System.out.println(Location);
		System.out.println(cuisine);
		System.out.println(email);
		String query = "INSERT INTO ordernow values(?,?,?,?,?)";	
		int result = 0;
		st = conn.prepareStatement(query);
		st.setString(1, type);
		st.setString(2, Restaurant);
		st.setString(3, Location);
		st.setString(4,cuisine);
		st.setString(5, email);
		result = st.executeUpdate();
		return result;
		
}
     public boolean ValidateOrder(orderbeans obean) throws SQLException{
			String type= obean.getType();
			String Restaurant = obean.getRestaurant();
			String Location = obean.getLocation();
			String cuisine = obean.getCuisine();
			String email = obean.getEmail();
			boolean result = false;
			String query = "select * from ordernow where type=? and Restauant=? and Location = ? and cuisine = ? and email = ?";
			st = conn.prepareStatement(query);
			st.setString(1, type);
			st.setString(2, Restaurant);
			st.setString(3, Location);
			st.setString(4,cuisine);
			st.setString(5, email);
			ResultSet rst = st.executeQuery();
			while(rst.next()){
				
				result = true;
			}
			
			return result;
}
     public List<orderbeans> orderedlist(String email)throws SQLException, ClassNotFoundException{
 		List<orderbeans> clist = new ArrayList<orderbeans>();
 		System.out.println("hi " + email);
 		String query = "SELECT * from ordernow where email = '" + email + "'";
 		//st.setString(1, user);
 		st = conn.prepareStatement(query);
 		ResultSet rst = st.executeQuery();
 		 System.out.println("hi i am in ordered list2");
 		orderbeans obean;
 		String email1;
 		while(rst.next()){
 			String type= rst.getString("type");
 			String Restaurant= rst.getString("Restaurant");
 			String Location = rst.getString("Location");
 			String cuisine= rst.getString("cuisine");
 	        email1 = rst.getString("email");
 			obean = new orderbeans(type, Restaurant, Location, cuisine,email1);
 			clist.add(obean);
 		}
 		
 		
 		return clist;
}
     public int cancelOrder(String email) throws SQLException {
	 		// TODO Auto-generated method stub
	 		int result = 0;
	 		String query = "DELETE  from ordernow where email=?";
				st=(PreparedStatement) conn.prepareStatement(query);
				st.setString(1, email);	 		
				result = st.executeUpdate();
				return result;
}
}
