package com.fingerlick.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionDAO {

	Connection conn = null;
	String user= "root";
	String url = "jdbc:mysql://localhost:3306/fl";
	String password = "123456";

	public Connection getConnection() throws ClassNotFoundException {
		//load driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, password);
			System.out.println(conn);
			System.out.println("MySQL driver loaded into memory");
			
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return conn;
		
	}
	public static void main(String args[]) throws ClassNotFoundException{
		ConnectionDAO cdao = new ConnectionDAO();
		System.out.println(cdao.getConnection());
	}

}
		
	
	




