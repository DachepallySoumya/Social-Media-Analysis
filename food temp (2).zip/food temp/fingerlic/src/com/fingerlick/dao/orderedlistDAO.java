package com.fingerlick.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fingerlick.beans.orderedlistbeans;

public class orderedlistDAO {
		ConnectionDAO cdao;
		Connection conn;
		PreparedStatement st;
		public orderedlistDAO() throws SQLException, ClassNotFoundException {
			System.out.println("after orderedlistdao");
			cdao = new ConnectionDAO();
			//System.out.println("connected");
			conn = cdao.getConnection();
		//	System.out.println("b4 create");
			}
	     public int CreateOrder(orderedlistbeans orderbean) throws SQLException{
	    	 String email = orderbean.getItem();
			String item = orderbean.getPrice();
			 String price =orderbean.getEmail();
			 System.out.println(item);
			System.out.println(price);
			System.out.println(email);
			String query = "INSERT INTO orderedlist values(?,?,?)";	
			int result = 0;
			st = conn.prepareStatement(query);
			st.setString(1, item); 
			st.setString(2, price);
			st.setString(3, email);
			result = st.executeUpdate();
			return result;
			
	}
	     public boolean ValidateOrder(orderedlistbeans orderbean) throws SQLException{
	    	 String email = orderbean.getItem();
				String item= orderbean.getPrice();
				String price = orderbean.getEmail();
				boolean result = false;
				String query = "select * from orderedlist where item = ?price=? and email=?";
				st = conn.prepareStatement(query);
				st.setString(1, item); 
				st.setString(2, price);
				st.setString(3, email);
				ResultSet rst = st.executeQuery();
				while(rst.next()){
					
					result = true;
				}
				
				return result;
	}
	    
	     public int cancelOrder(String email) throws SQLException {
		 		// TODO Auto-generated method stub
		 		int result = 0;
		 		String query = "DELETE  from orderedlist where email=?";
					st=(PreparedStatement) conn.prepareStatement(query);
					st.setString(1, email);	 		
					result = st.executeUpdate();
					return result;
	}
	     public List<orderedlistbeans> orderedlist(String email)throws SQLException, ClassNotFoundException{
	 		List<orderedlistbeans> clist = new ArrayList<orderedlistbeans>();
	 		System.out.println("hi " + email);
	 		String query = "SELECT * from orderedlist where email = '" + email + "'";
	 		 System.out.println("hi i am in orderedlist in controller"); 
	 		//st.setString(1, user);
	 		st = conn.prepareStatement(query);
	 		ResultSet rst = st.executeQuery();
	 		orderedlistbeans orderbean;
	 		String email1;
	 		while(rst.next()){
	 			 email1 = rst.getString("item");
	 			String item = rst.getString("price");
	 			String price= rst.getString("email");
	 			 orderbean = new orderedlistbeans(item,price,email1);
	 			clist.add(orderbean);
	 		}
	 		
	 		
	 		return clist;
	}
	}
