package com.fingerlick.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fingerlick.beans.orderedlistbeans;
import com.fingerlick.dao.orderedlistDAO;

public class orderedlistcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doProcess(request,response);	
		}

		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doProcess(request,response);	
		}
		protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			
			try
			{
				String item= request.getParameter("item");
				String price = request.getParameter("price");
				//String email = request.getParameter("email");
				//reading user from session
				
				String email = request.getParameter("email");
				HttpSession hs = request.getSession();
				hs.setAttribute("user", email);
				System.out.println(email);
				//creating ContactBean object with parameterized constructor
				orderedlistbeans orderbean = new orderedlistbeans (email,item,price);
				//creating ContactDAO object
				orderedlistDAO ud = new orderedlistDAO();
				//calling addContact() method
				int result = ud.CreateOrder(orderbean);
				System.out.println(result);
				//redirecting response
				if(result >=  1)
				{
					response.sendRedirect("welcome1.jsp?message=successfully ordered");
					
				}
				else
				{
					response.sendRedirect("orderedlist.jsp");
					
				}
			}
			catch (ClassNotFoundException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
