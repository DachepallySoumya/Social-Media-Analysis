package com.fingerlick.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import com.fingerlick.beans.UserBeans;
import com.fingerlick.dao.UserDAO;
public class logincontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public logincontroller() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	 
    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
			
				try {
					String email = request.getParameter("email");
					String password = request.getParameter("password");
					UserBeans ubean = new UserBeans(email, password);
					UserDAO utils;
					System.out.println("hi");
					utils = new UserDAO();
					boolean result = utils.ValidateUser(ubean);
						

						if(result){
							
							HttpSession hs = request.getSession();
							hs.setAttribute("sunm", email);
							
							response.sendRedirect("welcome1.jsp");
						}
						
						else{
							HttpSession hs = request.getSession();
							hs.removeAttribute("sunm");
							response.sendRedirect("login.jsp?email=" +email);
							
						}
				}
					 catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    }	
}
		


